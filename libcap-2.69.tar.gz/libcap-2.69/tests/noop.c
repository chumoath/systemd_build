#include <stdlib.h>

int main(int argc, char *argv[]) {
    exit(0);
}
